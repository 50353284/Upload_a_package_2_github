/*
 * JavaVM.h
 *
 * Copyright (C) 1997-2001, Apple Computer, Inc.
 * All Rights Reserved.
 *
 */

#import <JavaVM/NSJavaVirtualMachine.h>
#import <JavaVM/NSJavaConfiguration.h>

